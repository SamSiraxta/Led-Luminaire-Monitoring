﻿using System;
using System.Threading;

namespace Led_110718
{
    public class MainClass
    {
        internal static Byte[] dataSent;

        private static void Options()
        {
            // Error control memory
            bool ControlQ = false;

            // In case of an invalid option is typed in
            bool respNotOk = false;

            // DaliSocket object is generated to start off
            DaliSocket Dsocket = new DaliSocket();

            // Default color
            Console.ForegroundColor = ConsoleColor.White;

            // Command options to execute (we'd got two luminaires to experiment with)
            Console.WriteLine("Comandos que pueden ser enviados: ");
            Console.WriteLine("");
            Console.WriteLine("1. AD 00 00 03 00 AF	                    Shutdown ECE 01 of sub network 0");
            Console.WriteLine("2. AD 00 00 05 00 AF	                    Shutdown ECE 02 of sub network 0");
            Console.WriteLine("3. AD FF 00 FF 00 AF	                    Shutdown all ECEs from all the networks");
            Console.WriteLine("4. AD 00 00 03 05 AF	                    Turn ECE 01 on of sub network 0");
            Console.WriteLine("5. AD 00 00 05 05 AF	                    Turn ECE 02 on of sub network 0");
            Console.WriteLine("6. AD FF 00 FF 05 AF	                    Turn all ECEs from all the sub networks");
            Console.WriteLine("7. AD 00 01 03 92 AF                        Error control of ECE 01 in sub network 0");
            Console.WriteLine("8. AD 00 01 05 92 AF                        Error control of ECE 02 in sub network 0");
            Console.WriteLine("9. AD FC 09 10 00 01 02 00 20 01 21 43 AF   Commissioning all over the network");

            Console.WriteLine("");

            // Error management
            try
            {
                int answer = Convert.ToInt32(Console.ReadLine());
                switch (answer)
                {
                    case 1:
                        dataSent = new byte[] { 0xAD, 0x00, 0x00, 0x03, 0x00, 0xAF };
                        break;
                    case 2:
                        dataSent = new byte[] { 0xAD, 0x00, 0x00, 0x05, 0x00, 0xAF };
                        break;
                    case 3:
                        dataSent = new byte[] { 0xAD, 0xFF, 0x00, 0xFF, 0x00, 0xAF };
                        break;
                    case 4:
                        dataSent = new byte[] { 0xAD, 0x00, 0x00, 0x03, 0x05, 0xAF };
                        break;
                    case 5:
                        dataSent = new byte[] { 0xAD, 0x00, 0x00, 0x05, 0x05, 0xAF };
                        break;
                    case 6:
                        dataSent = new byte[] { 0xAD, 0xFF, 0x00, 0xFF, 0x05, 0xAF };
                        break;
                    case 7:
                        dataSent = new byte[] { 0xAD, 0x00, 0x01, 0x03, 0x92, 0xAF };
                        ControlQ = true;
                        break;
                    case 8:
                        dataSent = new byte[] { 0xAD, 0x00, 0x01, 0x05, 0x92, 0xAF };
                        ControlQ = true;
                        break;
                    case 9:
                        dataSent = new byte[] { 0xAD, 0xFC, 0x09, 0x10, 0x00, 0x01, 0x02, 0x00, 0x20, 0x01, 0x21, 0x43, 0xAF };  
                        break;
                    default:
                        Console.WriteLine("ERROR: Type in a correct option");
                        respNotOk = true;
                        break;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("ERROR: Type in a correct option!");
                respNotOk = true;
            }

            if (!respNotOk)
            {
                // Send datagram thru a socket
                Dsocket.SendAsSocket(dataSent, true, ControlQ);
            }
        }

        public static void Main(string[] args)
        {
            while (true)
            {
                Options();

                // Get space in text list
                Console.WriteLine("");
                Console.WriteLine("");

                Thread.Sleep(10);
            }
        }
    } 
}