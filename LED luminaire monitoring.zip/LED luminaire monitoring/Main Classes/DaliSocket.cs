﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Led_110718
{
    public class DaliSocket
    {
        // Static variables to IP address and PORT
        internal static String HOST = "192.168.1.250";
        internal static readonly int port = 10001;

        // Header memories 
        internal int posEnd = 0;
        internal int posBeg = 0;

        // Check-out headers variables
        internal bool principioTrama = false;
        internal bool finalTrama = false;

        // Error control memory
        internal bool cQ = false;

		// List in which the echo received (in DEC format) 
		// from radio-frequency repeater will be saved up
        internal List<int> Echo = new List<int>();

        // Close loop
        internal TreatMent tBack = new TreatMent();

        public Byte[] Send(Byte[] DaliDatagram)
        {
            // Generate an IP address and port
            IPAddress ipAddress = IPAddress.Parse(HOST);
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, port);

            // Buffer to get the response
            Byte[] bytesRecv = new Byte[24];

            // Error management
            try
            {
                // TcpSocket object is generated
                Socket TcpSocket = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

                // Establish communication
                TcpSocket.Connect(remoteEP);

                // Datagram is sent 
                int bytesSent = TcpSocket.Send(DaliDatagram);

                // Echo is received
                int bytesRec = TcpSocket.Receive(bytesRecv);

                // Socket is closed
                TcpSocket.Shutdown(SocketShutdown.Both);
                TcpSocket.Close();
            }
            catch (ArgumentNullException ane)
            {
                Console.WriteLine("ArgumentNullException: {0}", ane.ToString());
            }
            catch (SocketException se)
            {
                Console.WriteLine("SocketException: {0}", se.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception: {0}", e.ToString());
            }

            return bytesRecv;
        }

        public void CleanEcho(Byte[] bytesRecvClean)
        {
            // Clean Echo list
            Echo.Clear();

            // Response bits are saved up (buffer size: 20 bits)
            foreach (var item in bytesRecvClean)
            {
                Echo.Add(item);
            }
        }

        public void SendAsSocket(Byte[] DaliDatagram, bool ControlError, bool ControlQ)
        {
            // Identify if error control is sent
            cQ = ControlQ;

            if (!ControlError)
            {
                //Delay among error controls
                Thread.Sleep(500);
            }

            Byte[] bytesRecvSocket = Send(DaliDatagram);

            // Check the echo
            ResponseInterpreter(bytesRecvSocket, DaliDatagram);
        }

        // Cut out echo (I get the bits I'm interested in)
        public void MapEcho(int PosBeg, int PosEnd, Byte[] DaliDatagram)
        {

            // Store datagram buffer
            List<int> Map = new List<int>();

            // Reset 
            Reset();

            // Trim the map and check its size
            if (PosEnd - PosBeg >= 5)
            {
                for (int contMap = PosBeg; contMap <= PosEnd; contMap++)
                {
                    Map.Add(Echo[contMap]);
                }

                // Show echo map
                Console.Write("Echo received: ");

                foreach (var item in Map)
                {
                    Console.Write(item + " ");
                }

                // Get an analysis in case of commissioning
                tBack.ComS(Map, DaliDatagram);

                // Analyze error control
                if (cQ)
                {
                    tBack.Analyze(Map, PosEnd);
                }
            }
            else
            {
                SendAsSocket(DaliDatagram, true, cQ);
            }

        }

        public Byte[] SendWhenFailure(Byte[] DaliDatagram)
        {
            // Response buffer
            Byte[] bytesRecv = new Byte[24];

            bytesRecv = Send(DaliDatagram);

            return bytesRecv;
        }

        public void BufferRun()
        {
            // Go over the buffer
            for (int contBuff = 0; contBuff <= 20; contBuff++)
            {

                // Check the beginning
                if (!principioTrama && Echo[contBuff] == 173)
                {
                    posBeg = contBuff;
                    principioTrama = true;
                }
                // Check the ending
                if (!finalTrama && Echo[contBuff] == 175)
                {
                    posEnd = contBuff;
                    finalTrama = true;
                }
            }
        }

        public void Reset()
        {
            // Reset
            posEnd = 0;
            posBeg = 0;
            principioTrama = false;
            finalTrama = false;
        }

        public void Request(Byte[] DaliDatagram)
        {
           
		   // I do as many requests as needed to get a response
            while (!finalTrama || (posEnd == 0))
            {
				// 500 ms delay to receive a new response
                // If there's an error control, delay is set up to 1s
                Thread.Sleep(500);
                if (cQ) { Thread.Sleep(500); }
                Byte[] respData = SendWhenFailure(DaliDatagram);

				// Go over the buffer again
                CleanEcho(respData);
                BufferRun();
            }
        }

        public void ResponseInterpreter(Byte[] response, Byte[] DaliDatagram)
        {
            // Reset
            Reset();
            CleanEcho(response);
         
            BufferRun();

            // If in one time I receive both the headers
            if (principioTrama && finalTrama)
            {
                // Map echo
                MapEcho(posBeg, posEnd, DaliDatagram);
            }

            // If in one time I receive only the beginning header
            if (principioTrama && !finalTrama)
            {
                // Do a request
                Request(DaliDatagram);

                // Map Echo
                MapEcho(posBeg, posEnd, DaliDatagram);
            }

            // If in one time I only receive the ending header
            if (!principioTrama && finalTrama)
            {
                // I do as many requests as needed
                while (!principioTrama || (posBeg == 0))
                {
                    Request(DaliDatagram);
                }

                // Map echo
                MapEcho(posBeg, posEnd, DaliDatagram);
            }
        }
    }
}