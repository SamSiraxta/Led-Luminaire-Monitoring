﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Led_110718
{
    internal class TreatMent
    {
        public void Analyze(List<int> map, int PosEnd)
        {
            // Check if luminaire is in fault
            if (map[PosEnd - 1] == 255)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Luminaire is NOK");
            }

            // Check if luminaire is NOT in fault
            if (map[PosEnd - 1] != 255)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Luminaire is OK!");
            }
        }

        // Show how many clusters and luminaires are found out
        public void ComInterpreter(List<int> mapCom, int PosEnd)
        {
            // Commissioning memory
            bool bEnd = false;

            foreach (var item in mapCom)
            {
                // Check if there's 0x95 (Ending header)
                if (item == 149)
                {
                    bEnd = true;
                }
            }

            if (bEnd)
            {
                // Show how many luminaires are found
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Found: " + mapCom[PosEnd - 2] + " luminaires!");

                // Show how many clusters are found
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Found: " + mapCom[PosEnd - 4] + " clusters!");
            }
        }

        public void ComS(List<int> Map, Byte[] DaliDatagram)
        {
            // Commissioning memories
            bool bStart = true;
            bool bEnd = false;

            // 0x95 memory (ending header)
            int posEnd = 0;

            // Response to start the commissioning off
            List<int> lStart = new List<int> { 173, 252, 2, 243, 16, 175 };

            // Commissioning map
            List<int> MapC = new List<int>();

			// Get an IP address and PORT
            IPAddress ipAddress = IPAddress.Parse(DaliSocket.HOST);
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, DaliSocket.port);

            for (int cont = 0; cont < lStart.Count; cont++)

            {
                if (Map[cont] != lStart[cont])
                {
                    // If one element from the list doesn't coincide,
					// the commissioning is not started
                    bStart = false;
                }
            }

            if (bStart)
            {
                MapC.Clear();
                Console.WriteLine("");

                // Response datagram buffer
                Byte[] bytesRecv = new Byte[24];

                // Error management
                try
                {
  
                    Socket TcpSocket = new Socket(ipAddress.AddressFamily,
                    SocketType.Stream, ProtocolType.Tcp);

                    // Establish communication
                    TcpSocket.Connect(remoteEP);

                    // I get data from the net till I find 0x95 header out
                    do
                    {
                        MapC.Clear();

                        // I receive echo response  
                        int bytesRec = TcpSocket.Receive(bytesRecv);

                        int cont = 0;
                        foreach (var item in bytesRecv)
                        {
                            //Commissioning map
                            MapC.Add(item);

                            // If find an ending header, I leave the do-while loop
                            if (item == 149) { posEnd = cont + 5; bEnd = true; }

                            cont++;
                        }

                        // Delay not to saturate commissioning
                        Thread.Sleep(10);
                    } while (!bEnd);

                    // Close socket
                    TcpSocket.Shutdown(SocketShutdown.Both);
                    TcpSocket.Close();

                    // Analyze Commissioning map
                    ComInterpreter(MapC, posEnd);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Unexpected exception: {0}", e.ToString());
                }
            }
        }
    }
}